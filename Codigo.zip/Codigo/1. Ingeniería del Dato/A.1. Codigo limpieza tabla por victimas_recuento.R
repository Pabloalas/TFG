#
library(dplyr)
library(tidyr)

ciber_por_victima <- read_excel("Bases/BdD ciber (víctimas)(16-12).xlsx")

# Eliminar las columnas "Sextorsion" y "Doxing" del dataset
ciber_por_victima <- ciber_por_victima %>%
  select(-c(Sextorsion, Sexting))

#LIMPIEZA TABLA-----

# 1. Victima: NO NULOS
# transformación a variable caegorica porque es calve foranea

#3.Polivíctima: Si ha sido víctima de un agresor o varios en un o múltiples eventos
#Tiene nulos 224, Provienen en su mayoria de la Ertzaintza 

ciber_por_victima[is.na(ciber_por_victima$Polivíctima), ]
count(ciber_por_victima[is.na(ciber_por_victima$Polivíctima), ])
ciber_por_victima %>% group_by(Polivíctima, Demarcación ) %>% summarise(n = n())

ciber_por_victima %>% group_by(Polivíctima) %>% summarise( n=n())

#4. Demarcación
ciber_por_victima$Demarcación  <- factor(
  ciber_por_victima$Demarcación ,
  levels = c(1,2,3,4,5),  # Valores originales
  labels = c(
    "Guardia Civil",
    "Policía Nacional",
    "Mossos d’Esquadra",
    "Policía Foral de Navarra",
    "Ertzaintza"
  )
)

library(dplyr)

# Calcular el porcentaje de cada categoría en Demarcación
porcentaje_demarcacion <- ciber_por_victima %>%
  group_by(Demarcación) %>%
  summarise(n = n()) %>%
  mutate(porcentaje = (n / sum(n)) * 100)
ciber_por_victima %>% group_by(Demarcación) %>% summarise( n=n())

#5. Día
#6. Mes
#7. Año

#8. Fecha: Creada a través de Dia, Mes y Año

ciber_por_victima$fecha <- as.Date(
  paste(ciber_por_victima$Año, ciber_por_victima$Mes, ciber_por_victima$Dia, sep = "-"),  # Combina las variables con formato "YYYY-MM-DD"
  format = "%Y-%m-%d"                              # Especifica el formato de la fecha
)

ciber_por_victima <- ciber_por_victima %>%
  select(1:7, fecha, everything())
summary(ciber_por_victima$fecha)

#ciber_por_victima <- ciber_por_victima %>%
# filter(format(fecha, "%Y") != "2023")


#9. Lugar:

#10. CCAA:
ciber_por_victima$CCAA  <- factor(
  ciber_por_victima$CCAA ,
  levels = 1:19,  # Valores originales
  labels = c(
    "Andalucía",
    "Aragón",
    "Asturias",
    "Islas Baleares",
    "Islas Canarias",
    "Cantabria",
    "Castilla y León",
    "Castilla la Mancha",
    "Cataluña",
    "Comunidad Valenciana",
    "Extremadura",
    "Galicia",
    "Madrid",
    "Murcia",
    "Navarra",
    "País Vasco",
    "La Rioja",
    "Ceuta",
    "Melilla"
  )
)
ciber_por_victima %>% group_by(CCAA) %>% summarise( n=n())

str(ciber_por_victima)

#11. Info_Hecho:
# Cargar librerías necesarias
library(dplyr)
library(tidyr)

# Paso 1: Transformar valores específicos en Info_Hecho
ciber_por_victima <- ciber_por_victima %>%
  mutate(across(starts_with("Info_Hecho"), ~ case_when(
    . == 2 ~ 3,  # Transformar 2 a 3
    . == 4 ~ 5,  # Transformar 4 a 5
    . == 8 ~ 9,  # Transformar 8 a 9
    TRUE ~ .     # Mantener el resto de los valores
  )))

# Paso 2: Definir categorías y sus valores equivalentes
categorias <- list(
  "Ciberacoso" = c(1),
  "Ciberamenaza" = c(3),
  "Ciberquebrantamiento_de_condena" = c(5),
  "Descubrimiento_y_revelacion_de_secretos" = c(6),
  "Coacciones" = c(7),
  "Ciberofensas" = c(9),
  "Contacto_no_deseado" = c(10),
  "Suplantacion_de_identidad" = c(11)
)

# Paso 3: Transformar los datos a formato largo (manteniendo valores nulos)
ciber_por_victima_long <- ciber_por_victima %>%
  select(IDCaso, starts_with("Info_Hecho")) %>%
  pivot_longer(cols = starts_with("Info_Hecho"), 
               names_to = "Info_Hecho", 
               values_to = "Categoria")

# Paso 4: Crear una columna de conteo para cada categoría
ciber_por_victima_long <- ciber_por_victima_long %>%
  mutate(
    Categoria = as.numeric(Categoria),
    Info_Hecho_Ciberacoso = if_else(Categoria %in% c(1), 1, 0),
    Info_Hecho_Ciberamenaza = if_else(Categoria %in% c(3), 1, 0),
    Info_Hecho_Ciberquebrantamiento_de_condena = if_else(Categoria %in% c(5), 1, 0),
    Info_Hecho_Descubrimiento_y_revelacion_de_secretos = if_else(Categoria %in% c(6), 1, 0),
    Info_Hecho_Coacciones = if_else(Categoria %in% c(7), 1, 0),
    Info_Hecho_Ciberofensas = if_else(Categoria %in% c(9), 1, 0),
    Info_Hecho_Contacto_no_deseado = if_else(Categoria %in% c(10), 1, 0),
    Info_Hecho_Suplantacion_de_identidad = if_else(Categoria %in% c(11), 1, 0)
  )

# Paso 5: Consolidar los conteos por `IDCaso`
ciber_por_victima_conteo <- ciber_por_victima_long %>%
  group_by(IDCaso) %>%
  summarise(
    Info_Hecho_Ciberacoso = sum(Info_Hecho_Ciberacoso, na.rm = TRUE),
    Info_Hecho_Ciberamenaza = sum(Info_Hecho_Ciberamenaza, na.rm = TRUE),
    Info_Hecho_Ciberquebrantamiento_de_condena = sum(Info_Hecho_Ciberquebrantamiento_de_condena, na.rm = TRUE),
    Info_Hecho_Descubrimiento_y_revelacion_de_secretos = sum(Info_Hecho_Descubrimiento_y_revelacion_de_secretos, na.rm = TRUE),
    Info_Hecho_Coacciones = sum(Info_Hecho_Coacciones, na.rm = TRUE),
    Info_Hecho_Ciberofensas = sum(Info_Hecho_Ciberofensas, na.rm = TRUE),
    Info_Hecho_Contacto_no_deseado = sum(Info_Hecho_Contacto_no_deseado, na.rm = TRUE),
    Info_Hecho_Suplantacion_de_identidad = sum(Info_Hecho_Suplantacion_de_identidad, na.rm = TRUE)
  )

# Paso 6: Unir las columnas de conteo al dataset original
ciber_por_victima <- ciber_por_victima %>%
  left_join(ciber_por_victima_conteo, by = "IDCaso")

# Verificar si la columna "Suplantacion_de_identidad" fue creada correctamente
print(ciber_por_victima$Info_Hecho_Suplantacion_de_identidad)

# Sumar el total de eventos de "Suplantacion_de_identidad"
conteo_suplantacion <- ciber_por_victima %>%
  summarise(total = sum(Info_Hecho_Suplantacion_de_identidad, na.rm = TRUE))

# Mostrar la suma total de eventos de Suplantación de Identidad
print(conteo_suplantacion)




ciber_por_victima <- ciber_por_victima %>%
  select(-c(Info_Hecho_1, Info_Hecho_2, Info_Hecho_3, Info_Hecho_4, Info_Hecho_5, Info_Hecho_6))


#12. TipologíaCiberHecho
# Cargar librerías necesarias
library(dplyr)
library(tidyr)

# Lista de categorías según los valores numéricos
categorias <- c("Stalking", "Sexting", "Sextorsion", "Revenge_Porn", 
                "Doxing", "Flaming", "Fraping", "Denigration", "Impersonation")

# Paso 1: Transformar los datos a formato largo (manteniendo los nulos)
ciber_por_victima_long <- ciber_por_victima %>%
  select(IDCaso, starts_with("TipologiaCiberHecho")) %>%
  pivot_longer(cols = starts_with("TipologiaCiberHecho"), 
               names_to = "TipologiaCiberHecho", 
               values_to = "Categoria") 

# Paso 2: Crear variables de conteo para cada categoría sin eliminar NA
ciber_por_victima_long <- ciber_por_victima_long %>%
  mutate(Categoria = factor(Categoria, levels = 0:8, labels = categorias)) %>%
  group_by(IDCaso, Categoria) %>%
  summarise(Conteo = sum(!is.na(Categoria)), .groups = "drop") %>%  # Contar sin eliminar NA
  pivot_wider(names_from = "Categoria", values_from = "Conteo", values_fill = list(Conteo = 0))  # Mantener NA

# Paso 3: Unir la tabla agregada sin duplicar valores
ciber_por_victima <- ciber_por_victima %>%
  left_join(ciber_por_victima_long, by = "IDCaso") %>%
  mutate(across(all_of(categorias), ~ replace_na(.x, 0)))  # Reemplazar NA por 0 solo una vez

# Verificar la estructura final para asegurarse de que no haya duplicados
str(ciber_por_victima)

# Paso 4: Calcular el total de eventos de "Stalking"
conteo_stalking <- ciber_por_victima %>%
  summarise(total = sum(Stalking, na.rm = TRUE))

# Mostrar la suma total de eventos de "Stalking"
print(conteo_stalking)


#13. Ambito_Hecho

# Cargar librerías necesarias
library(dplyr)
library(tidyr)

# Paso 1: Transformar datos en formato largo (manteniendo los NA)
ciber_por_victima_long <- ciber_por_victima %>%
  select(IDCaso, starts_with("Ambito_Hecho")) %>%
  pivot_longer(cols = starts_with("Ambito_Hecho"), names_to = "Ambito_Hecho", values_to = "Ambito") 

# Paso 2: Crear variables de conteo para Ambito_Hecho_Privado y Ambito_Hecho_Publico
ciber_por_victima_conteo <- ciber_por_victima_long %>%
  group_by(IDCaso, Ambito) %>%
  summarise(Conteo = n(), .groups = "drop") %>%
  pivot_wider(names_from = "Ambito", values_from = "Conteo", values_fill = list(Conteo = 0))  # Convertir en columnas

# Verificar nombres de columnas generadas antes del join
print(colnames(ciber_por_victima_conteo))

# Asegurar que las columnas "0" (Público) y "1" (Privado) existen antes de renombrarlas
if (!"1" %in% colnames(ciber_por_victima_conteo)) {
  ciber_por_victima_conteo <- ciber_por_victima_conteo %>% mutate(`1` = 0)
}
if (!"0" %in% colnames(ciber_por_victima_conteo)) {
  ciber_por_victima_conteo <- ciber_por_victima_conteo %>% mutate(`0` = 0)
}

# Renombrar las columnas después de la conversión
ciber_por_victima_conteo <- ciber_por_victima_conteo %>%
  rename(Ambito_Hecho_Publico = `0`, Ambito_Hecho_Privado = `1`)

# Paso 3: Unir la tabla agregada sin duplicar valores
ciber_por_victima <- ciber_por_victima %>%
  left_join(ciber_por_victima_conteo, by = "IDCaso") %>%
  mutate(across(c("Ambito_Hecho_Publico", "Ambito_Hecho_Privado"), ~ replace_na(.x, 0)))  # Reemplazar NA por 0

# Paso 4: Verificar la estructura final
str(ciber_por_victima)

# Paso 5: Sumar el total de eventos de "Ambito_Hecho_Publico"
conteo_ambito_publico <- ciber_por_victima %>%
  summarise(total = sum(Ambito_Hecho_Publico, na.rm = TRUE))

# Mostrar la suma total de eventos de "Ambito_Hecho_Publico"
print(conteo_ambito_publico)

#14. Lugar Hecho


# Lista de categorías según los valores numéricos
categorias <- c("SMS", "Whatsapp", "Facebook", "Instagram", "Página_web", 
                "Llamada_telefónica", "Offline", "Correo_electrónico", "Twitter")

# Paso 1: Transformar los datos a formato largo (manteniendo los NA)
ciber_por_victima_long <- ciber_por_victima %>%
  select(IDCaso, starts_with("Lugar_Hecho")) %>%
  pivot_longer(cols = starts_with("Lugar_Hecho"), names_to = "Lugar_Hecho", values_to = "Categoria") 

# Paso 2: Crear variables de conteo para cada categoría
ciber_por_victima_conteo <- ciber_por_victima_long %>%
  mutate(Categoria = factor(Categoria, levels = 0:8, labels = categorias)) %>%
  group_by(IDCaso, Categoria) %>%
  summarise(Conteo = n(), .groups = "drop") %>%
  pivot_wider(names_from = "Categoria", values_from = "Conteo", values_fill = list(Conteo = 0))  # Expandir columnas

# Paso 3: Asegurar que todas las categorías existen antes del `left_join()`
for (cat in categorias) {
  if (!(cat %in% colnames(ciber_por_victima_conteo))) {
    ciber_por_victima_conteo[[cat]] <- 0  # Crear la columna faltante con valores 0
  }
}

# Paso 4: Unir las columnas de conteo con el dataset original
ciber_por_victima <- ciber_por_victima %>%
  left_join(ciber_por_victima_conteo, by = "IDCaso") %>%
  mutate(across(all_of(categorias), ~ replace_na(.x, 0)))  # Asegurar que no haya NA, reemplazándolos con 0

# Paso 5: Verificar la estructura final
str(ciber_por_victima)

# Paso 6: Sumar el total de eventos por Lugar_Hecho
conteo_lugar_hecho <- ciber_por_victima %>%
  summarise(across(all_of(categorias), sum, na.rm = TRUE))

# Mostrar la suma total de eventos por cada tipo de "Lugar_Hecho"
print(conteo_lugar_hecho)

# Eliminar columnas innecesarias si existen
ciber_por_victima <- ciber_por_victima %>%
  select(-c(Lugar_Hecho_1, Lugar_Hecho_2, Lugar_Hecho_3, Lugar_Hecho_4, Lugar_Hecho_5, Lugar_Hecho_6))

#15. EspecificarLugarHecho


ciber_por_victima <- ciber_por_victima %>%
  select(-c(EspecificarLugarHecho1, EspecificarLugarHecho2, EspecificarLugarHecho3,
            EspecificarLugarHecho4,
            EspecificarLugarHecho5))

#16. Comunicación_Hecho
ciber_por_victima <- ciber_por_victima %>%
  select(-c(Comunicación_Hecho_1, Comunicación_Hecho_2, Comunicación_Hecho_3, 
            Comunicación_Hecho_4, Comunicación_Hecho_5, Comunicación_Hecho_6))


#17.Frecuencia_Hecho 

ciber_por_victima <- ciber_por_victima %>%
  select(-c(Frecuencia_Hecho_1, Frecuencia_Hecho_2, Frecuencia_Hecho_3, 
            Frecuencia_Hecho_4, Frecuencia_Hecho_5, Frecuencia_Hecho_6))

#18. ATravésMovilAutor_Hecho

# Paso 1: Transformar los datos a formato largo
ciber_por_victima_long <- ciber_por_victima %>%
  select(IDCaso, starts_with("ATravésMovilAutor_Hecho")) %>%
  pivot_longer(cols = starts_with("ATravésMovilAutor_Hecho"), 
               names_to = "ATravésMovilAutor_Hecho", 
               values_to = "Ambito") 

# Paso 2: Crear variable de conteo para "ATravésMovilAutor_Hecho_Si" y eliminar "No"
ciber_por_victima_conteo <- ciber_por_victima_long %>%
  filter(Ambito == 1) %>%  # Solo contar los valores donde Ambito = 1
  group_by(IDCaso) %>%
  summarise(ATravésMovilAutor_Hecho_Si = n(), .groups = "drop")  # Contar ocurrencias por víctima

# Paso 3: Unir la tabla agregada con el dataset original
ciber_por_victima <- ciber_por_victima %>%
  left_join(ciber_por_victima_conteo, by = "IDCaso") %>%
  mutate(ATravésMovilAutor_Hecho_Si = replace_na(ATravésMovilAutor_Hecho_Si, 0))  # Reemplazar NA por 0

# Paso 4: Verificar la estructura final
str(ciber_por_victima)

# Paso 5: Sumar el total de eventos de "ATravésMovilAutor_Hecho_Si"
conteo_movil_autor <- ciber_por_victima %>%
  summarise(total = sum(ATravésMovilAutor_Hecho_Si, na.rm = TRUE))

# Mostrar la suma total de eventos de "ATravésMovilAutor_Hecho_Si"
print(conteo_movil_autor)

# Eliminar columnas innecesarias si existen
ciber_por_victima <- ciber_por_victima %>%
  select(-c(ATravésMovilAutor_Hecho1, ATravésMovilAutor_Hecho2, ATravésMovilAutor_Hecho3,
            ATravésMovilAutor_Hecho4, ATravésMovilAutor_Hecho5,
            ATravésMovilAutor_Hecho6))


#19. ATravésTercerasPersonas_Hecho

# Paso 1: Transformar los datos a formato largo
ciber_por_victima_long <- ciber_por_victima %>%
  select(IDCaso, starts_with("ATravésTercerasPersonas_Hecho")) %>%
  pivot_longer(cols = starts_with("ATravésTercerasPersonas_Hecho"), 
               names_to = "ATravésTercerasPersonas_Hecho", 
               values_to = "Ambito") 

# Paso 2: Crear variable de conteo para "ATravésTercerasPersonas_Hecho_Si" y eliminar "No"
ciber_por_victima_conteo <- ciber_por_victima_long %>%
  filter(Ambito == 1) %>%  # Solo contar los valores donde Ambito = 1
  group_by(IDCaso) %>%
  summarise(ATravésTercerasPersonas_Hecho_Si = n(), .groups = "drop")  # Contar ocurrencias por víctima

# Paso 3: Unir la tabla agregada con el dataset original
ciber_por_victima <- ciber_por_victima %>%
  left_join(ciber_por_victima_conteo, by = "IDCaso") %>%
  mutate(ATravésTercerasPersonas_Hecho_Si = replace_na(ATravésTercerasPersonas_Hecho_Si, 0))  # Reemplazar NA por 0

# Paso 4: Verificar la estructura final
str(ciber_por_victima)

# Paso 5: Sumar el total de eventos de "ATravésTercerasPersonas_Hecho_Si"
conteo_terceras_personas <- ciber_por_victima %>%
  summarise(total = sum(ATravésTercerasPersonas_Hecho_Si, na.rm = TRUE))

# Mostrar la suma total de eventos de "ATravésTercerasPersonas_Hecho_Si"
print(conteo_terceras_personas)

# Eliminar columnas innecesarias si existen
ciber_por_victima <- ciber_por_victima %>%
  select(-c(ATravésTercerasPersonas_Hecho1, ATravésTercerasPersonas_Hecho2, ATravésTercerasPersonas_Hecho3,
            ATravésTercerasPersonas_Hecho4, ATravésTercerasPersonas_Hecho5,
            ATravésTercerasPersonas_Hecho6), everything())


#20. IdentificabilidadAutor_Hecho
ciber_por_victima <- ciber_por_victima %>%
select(-c(IdentificabilidadAutor_Hecho1, IdentificabilidadAutor_Hecho2, IdentificabilidadAautor_Hecho3,
          IdentificabilidadAutor_Hecho4, IdentificabilidadAutor_Hecho5,
          IdentificabilidadAutor_Hecho6))

#21.Descripción: 15 descripciones faltantes, 5 casos distintos
ciber_por_victima[is.na(ciber_por_victima$Descripcion), ]


ciber_por_victima <- ciber_por_victima %>%
  select(1:20, Descripcion, everything())

#22. NVictimas
ciber_por_victima <- ciber_por_victima %>%
  select(1:21, NVictimas, everything())

ciber_por_victima %>% group_by(NVictimas) %>% summarise( n=n())

#23. VPR : Hay 68 Nulos
ciber_por_victima[is.na(ciber_por_victima$VPR), ]
ciber_por_victima$VPR[ciber_por_victima$VPR == 5] <- NA

ciber_por_victima$VPR <- factor(ciber_por_victima$VPR,
                                 levels = 0:4,
                                 labels = c("No apreciado", 
                                            "Bajo", 
                                            "Medio", 
                                            "Alto", 
                                            "Extremo" 
                                 ))

ciber_por_victima <- ciber_por_victima %>%
  select(1:22, VPR, everything())

ciber_por_victima %>% group_by(VPR) %>% summarise( n=n())

#24. Tipo de delito
ciber_por_victima[is.na(ciber_por_victima$TipoDelito), ]

ciber_por_victima <- ciber_por_victima %>%
  select(1:23, TipoDelito, everything())

ciber_por_victima %>% group_by(VPR) %>% summarise( n=n())

#2X. Numero de delitos:

#24. NºDelitos_vg del 1 al 5
ciber_por_victima[is.na(ciber_por_victima$NºDelitos_vg), ]

ciber_por_victima %>% 
  group_by(NºDelitos_vg) %>% 
  summarise(n = n())

# 25.1 Violencia de género: Si (1) / No (0)
# No hay cambios adicionales especificados para esta variable en el enunciado

ciber_por_victima %>% 
  group_by(Violencia_género) %>% 
  summarise(n = n())

# 25.2 Violencia psicológica y física: Si (1) / No (0)
ciber_por_victima %>% 
  group_by(Violencia_psicologicayfisica) %>% 
  summarise(n = n())


ciber_por_victima$Violencia_psicologicayfisica[is.na(ciber_por_victima$Violencia_psicologicayfisica)] <- 0
# No cambiar, se desconoce

# 25.3 Malos tratos en ámbito familiar: Si (1) / No (0)
# No hay instrucciones específicas, así que mantenemos los valores actuales.

ciber_por_victima %>% 
  group_by(MalosTratosAmbFam) %>% 
  summarise(n = n())
# 25.4 Malos tratos físicos: Si (1) / No (0)
# No hay cambios adicionales especificados para esta variable en el enunciado
ciber_por_victima %>% 
  group_by(MalosTratosFísicos) %>% 
  summarise(n = n())

# 25.5 Malos tratos psíquicos: Si (1) / No (0)
# No hay instrucciones específicas, así que mantenemos los valores actuales.
ciber_por_victima %>% 
  group_by(MalosTratosPsíquicos) %>% 
  summarise(n = n())

# 25.6 Coacciones: Si (1) / No (0)
# No hay cambios adicionales especificados para esta variable en el enunciado
ciber_por_victima %>% 
  group_by(Coacciones) %>% 
  summarise(n = n())

# 25.7 Amenazas: Si (1) / No (0)
# No hay instrucciones específicas, así que mantenemos los valores actuales.
ciber_por_victima %>% 
  group_by(Amenazas) %>% 
  summarise(n = n())

# 25.8 Acoso: Si (1) / No (0)
# No hay instrucciones específicas, así que mantenemos los valores actuales.
ciber_por_victima %>% 
  group_by(Acoso) %>% 
  summarise(n = n())
# 25.9 Vejaciones: Si (1) / No (0)
# No hay cambios adicionales especificados para esta variable en el enunciado
ciber_por_victima %>% 
  group_by(Vejaciones) %>% 
  summarise(n = n())
# 25.10 Injurias: Si (1) / No (0)
# No hay instrucciones específicas, así que mantenemos los valores actuales.
ciber_por_victima %>% 
  group_by(Injurias) %>% 
  summarise(n = n())
# 25.11 Descubrimiento y revelación de secretos: Si (1) / No (0)
# No hay cambios adicionales especificados para esta variable en el enunciado
ciber_por_victima %>% 
  group_by(Descubrimiento_revelación_secretos) %>% 
  summarise(n = n())
# 25.12 Suplantación de identidad: Si (1) / No (0)
# No hay instrucciones específicas, así que mantenemos los valores actuales.
ciber_por_victima %>% 
  group_by(Suplantación_Identidad) %>% 
  summarise(n = n())
# 25.13 Delito contra la libertad: Si (1) / No (0)
# No hay cambios adicionales especificados para esta variable en el enunciado
ciber_por_victima %>% 
  group_by(DelitoContraLibertad) %>% 
  summarise(n = n())
# 25.14 Agresión física: Si (1) / No (0)
# No hay instrucciones específicas, así que mantenemos los valores actuales.

ciber_por_victima %>% 
  group_by(Agresión_física) %>% 
  summarise(n = n())
# 25.15 Daños: Si (1) / No (0)
# No hay cambios adicionales especificados para esta variable en el enunciado
ciber_por_victima %>% 
  group_by(Daños) %>% 
  summarise(n = n())
# 25.16 Torturas: Si (1) / No (0)
# No hay instrucciones específicas, así que mantenemos los valores actuales.
ciber_por_victima %>% 
  group_by(Torturas) %>% 
  summarise(n = n()) 
# 25.17 Abuso sexual: Si (1) / No (0)
# Hay 3 nulos. Pertenecen a la víctima 236. Tratarlo como cero.
ciber_por_victima$AbusoSexual[is.na(ciber_por_victima$AbusoSexual)] <- 0
ciber_por_victima %>% 
  group_by(AbusoSexual) %>% 
  summarise(n = n())

#  25.18. Quebrantamiento medida Cautelar
sum(is.na(ciber_por_victima$QuebrantamientoMedidaCautelar))

ciber_por_victima %>% 
  group_by(QuebrantamientoMedidaCautelar) %>% 
  summarise(n = n())
# 25.18.1 TipoQueb (Quebrantamiento de medida cautelar)
# Tiene 337 nulos. Eliminar la categoría 6 (que corresponde a 5 en el índice de R).
ciber_por_victima$TipoQueb[ciber_por_victima$TipoQueb == 5] <- NA
sum(is.na(ciber_por_victima$TipoQueb))  # Contar los valores nulos en esta variable después del cambio

ciber_por_victima %>% 
  group_by(TipoQueb) %>% 
  summarise(n = n())


library(dplyr)



# 1.2. Variable Victima --------------------------------------------------------

# 26, 27, 28 y 29: Edad, edad Rango, nacionalidad y situacion legal presentan 4 nulos
#son Victima 83 y 262

ciber_por_victima[is.na(ciber_por_victima$Edad), ]
#view(ciber_por_victima[is.na(ciber_por_victima$Nacionalidad),])

#edad

#27. EdadRango

# Transformar la variable EdadRango en categórica con los rangos especificados basándose en Edad


ciber_por_victima <- ciber_por_victima %>%
  mutate(
    EdadRango = case_when(
      Edad < 18 ~ "< 18",
      Edad >= 18 & Edad <= 30 ~ "18-30",
      Edad >= 31 & Edad <= 45 ~ "31-45",
      Edad >= 46 & Edad <= 60 ~ "46-60",
      Edad >= 61 & Edad <= 75 ~ "61-75",
      Edad > 75 ~ "> 75",
      TRUE ~ "Sin clasificación" # Por si hay valores fuera de estos rangos
    )
  )

ciber_por_victima <- ciber_por_victima %>%
  mutate(EdadRango = factor(EdadRango, 
                            levels = c("< 18", "18-30", "31-45", 
                                       "46-60", "61-75", "> 75")))
ciber_por_victima %>% 
  group_by(EdadRango) %>% 
  summarise(n = n())

#28. Nacionalidad: 
ciber_por_victima <- ciber_por_victima %>%
  mutate(
    Nacionalidad = case_when(
      Nacionalidad == 0 ~ "Nacional",          # Valor 0 se convierte en "Nacional"
      Nacionalidad == 1 ~ "Extranjera",        # Valor 1 se convierte en "Extranjera"
      Nacionalidad == 2 ~ "Doble nacionalidad" # Valor 2 se convierte en "Doble nacionalidad"
      
    ),
    Nacionalidad = factor(Nacionalidad, levels = c("Nacional", "Extranjera", "Doble nacionalidad", NA))
  )


ciber_por_victima %>% 
  group_by(Nacionalidad) %>% 
  summarise(n = n())


#29. Pais de nacimiento
ciber_por_victima <- ciber_por_victima %>%
  mutate(
    PaisNacimiento = case_when(
      PaisNacimiento == 1 ~ "Argelia",
      PaisNacimiento == 2 ~ "Argentina",
      PaisNacimiento == 3 ~ "Armenia",
      PaisNacimiento == 4 ~ "Bolivia",
      PaisNacimiento == 5 ~ "Brasil",
      PaisNacimiento == 6 ~ "Bulgaria",
      PaisNacimiento == 7 ~ "Colombia",
      PaisNacimiento == 8 ~ "Cuba",
      PaisNacimiento == 9 ~ "Ecuador",
      PaisNacimiento == 10 ~ "España",
      PaisNacimiento == 11 ~ "Filipinas",
      PaisNacimiento == 12 ~ "Francia",
      PaisNacimiento == 13 ~ "Georgia",
      PaisNacimiento == 14 ~ "Guinea Ecuatorial",
      PaisNacimiento == 15 ~ "Honduras",
      PaisNacimiento == 16 ~ "Italia",
      PaisNacimiento == 17 ~ "Jordania",
      PaisNacimiento == 18 ~ "Marruecos",
      PaisNacimiento == 19 ~ "Nicaragua",
      PaisNacimiento == 20 ~ "Países Bajos",
      PaisNacimiento == 21 ~ "Paraguay",
      PaisNacimiento == 22 ~ "Perú",
      PaisNacimiento == 23 ~ "Polonia",
      PaisNacimiento == 24 ~ "Reino Unido",
      PaisNacimiento == 25 ~ "República Checa",
      PaisNacimiento == 26 ~ "República Dominicana",
      PaisNacimiento == 27 ~ "Rumanía",
      PaisNacimiento == 28 ~ "Rusia",
      PaisNacimiento == 29 ~ "Ucrania",
      PaisNacimiento == 30 ~ "Uruguay",
      PaisNacimiento == 31 ~ "Venezuela"
    ),
    PaisNacimiento = factor(PaisNacimiento, levels = c("Argelia", "Argentina", "Armenia", "Bolivia", "Brasil", "Bulgaria", 
                                                       "Colombia", "Cuba", "Ecuador", "España", "Filipinas", "Francia", 
                                                       "Georgia", "Guinea Ecuatorial", "Honduras", "Italia", "Jordania", 
                                                       "Marruecos", "Nicaragua", "Países Bajos", "Paraguay", "Perú", "Polonia", 
                                                       "Reino Unido", "República Checa", "República Dominicana", "Rumanía", 
                                                       "Rusia", "Ucrania", "Uruguay", "Venezuela"))
  )

ciber_por_victima %>% 
  group_by(PaisNacimiento) %>% 
  summarise(n = n())


#29.1: Continente:

# Definir Continente según el País de Nacimiento
ciber_por_victima <- ciber_por_victima %>%
  mutate(ContinenteNacimientoVictima = case_when(
    PaisNacimiento %in% c("España", "Francia", "Italia", "Países Bajos", "Polonia", 
                          "Reino Unido", "República Checa", "Rumanía", "Bulgaria") ~ "Europa",
    
    PaisNacimiento %in% c("Argentina", "Bolivia", "Brasil", "Colombia", "Cuba", "Ecuador",
                          "Honduras", "Nicaragua", "Paraguay", "Perú", "Uruguay", "Venezuela",
                          "República Dominicana") ~ "América",
    
    PaisNacimiento %in% c("Argelia", "Marruecos", "Guinea Ecuatorial") ~ "África",
    
    PaisNacimiento %in% c("Filipinas", "Jordania", "Georgia", "Armenia", "Rusia", "Ucrania") ~ "Asia",
    
    TRUE ~ NA  # Para casos no especificados
  ))

ciber_por_victima %>% 
  group_by(ContinenteNacimientoVictima) %>% 
  summarise(n = n())

#30. Situación Legal:

ciber_por_victima <- ciber_por_victima %>% 
  rename("SituacionLegal" = SitucionLegal)


ciber_por_victima <- ciber_por_victima %>%
  mutate(
    SituacionLegal = case_when(
      SituacionLegal == 0 ~ "Irregular",
      SituacionLegal == 1 ~ "Regular",
      SituacionLegal == 2 ~ "Nacional"
    ),
    SituacionLegal = factor(SituacionLegal, levels = c("Irregular", "Regular", "Nacional" ))
  )


ciber_por_victima[is.na(ciber_por_victima$SituacionLegal), ]

#31. Situación  Laboral tiene 378 nulos cuando deberían de ser parte de la categoria 7 (Se desconoce)
#nos cargamos la categoria 7 y los ponemos todos como nulos, ahora 520  .

ciber_por_victima$SituacionLaboral[(ciber_por_victima$SituacionLaboral) == 7] <- NA

is.na(ciber_por_victima$SituacionLaboral)
sum(is.na(ciber_por_victima$SituacionLaboral))

#32.Ocupación: Varable descriptiva que viene explicada por ocupación_R,
ciber_por_victima <-ciber_por_victima %>% select(-Ocupacion)

#32.1. Ocupación_R y ocupacion TIENE 1092 NULOS

sum(is.na(ciber_por_victima$Ocupación_R))


#33. Unidad de Convivencia
#33.1 Vive Sola: 363 nulos
sum(is.na(ciber_por_victima$ViveSola))

ciber_por_victima %>% 
  group_by(ViveSola) %>% 
  summarise(n = n())

#33.2 Vive con Autor: 4 Nulos
sum(is.na(ciber_por_victima$ViveAutor))
view(ciber_por_victima[is.na(ciber_por_victima$ViveAutor), ])

ciber_por_victima %>% 
  group_by(ViveAutor) %>% 
  summarise(n = n())

#33.3 Vive con Autor y con otras personas: 4 Nulos
sum(is.na(ciber_por_victima$ViveAutoryOtras))


ciber_por_victima %>% 
  group_by(ViveAutoryOtras) %>% 
  summarise(n = n())


#33.4 Vive solo con otras personas: 134 nulos
sum(is.na(ciber_por_victima$NoAutorSiOtras))



ciber_por_victima %>% 
  group_by(NoAutorSiOtras) %>% 
  summarise(n = n())


#ESTADO VIVIENDA INCONSISTENCIAS VARIAS
df_invalidas_VIVIENDA_VICTIMA <- ciber_por_victima %>%
  filter(!(
    (ViveSola == 1 & ViveAutor == 0 & ViveAutoryOtras == 0 & NoAutorSiOtras == 0) |
      (ViveSola == 0 & ViveAutor == 1 & ViveAutoryOtras == 0 & NoAutorSiOtras == 0) |
      (ViveSola == 0 & ViveAutor == 1 & ViveAutoryOtras == 1 & NoAutorSiOtras == 0) |
      (ViveSola == 0 & ViveAutor == 0 & ViveAutoryOtras == 0 & NoAutorSiOtras == 1) |
      (ViveSola == "NULO" & ViveAutor == 0 & ViveAutoryOtras == 0 & NoAutorSiOtras == "NULO") |
      (ViveSola == "NULO" & ViveAutor == "NULO" & ViveAutoryOtras == "NULO" & NoAutorSiOtras == "NULO")
  ))




#34. Hijos
ciber_por_victima$Hijos

#34.1. Nhijos: 203 nulos
sum(is.na(ciber_por_victima$Hijos))

#34.2. NHijos por autor: 118 nulos
sum(is.na(ciber_por_victima$HijosAutor))
ciber_por_victima %>% group_by(HijosAutor) %>% summarise( n=n())

#Hijos_R
ciber_por_victima <- ciber_por_victima %>%
  mutate(Hijos_R = case_when(
    Hijos > 0 ~ "1",   # Si tiene al menos un hijo, asignar "Sí"
    Hijos == 0 ~ "0",  # Si el número de hijos es 0, asignar "No"
    is.na(Hijos) ~ NA # Tratar valores NA como "No"
  ))

ciber_por_victima %>% group_by(Hijos_R) %>% summarise( n=n())


#34.2.1 Hijos con autor


# Crear una nueva variable dicotómica basada en HijosAutor
ciber_por_victima <- ciber_por_victima %>%
  mutate(HijosConAutor = case_when(
    HijosAutor > 0 ~ "1",   # Si tiene al menos un hijo, asignar "Sí"
    HijosAutor == 0 ~ "0", # Tratar valores NA
  ))

ciber_por_victima %>% group_by(HijosConAutor) %>% summarise( n=n())

#34.3. Hijos con otra persona: 212 nulos
sum(is.na(ciber_por_victima$HijosOtro))
ciber_por_victima %>% group_by(HijosOtro) %>% summarise( n=n())

# Filtrar las observaciones que no cumplen con los patrones deseados
df_invalidas_hijos <- ciber_por_victima %>%
  filter(!(
    (Hijos == 1 & HijosAutor == 0 & HijosOtro == 1) |
      (Hijos == 1 & HijosAutor == 1 & HijosOtro == 0) |
      (Hijos == 2 & HijosAutor == 2 & HijosOtro == 0) |
      (Hijos == 2 & HijosAutor == 1 & HijosOtro == 1) |
      (Hijos == 2 & HijosAutor == 0 & HijosOtro == 2) |
      (Hijos == 3 & HijosAutor == 3 & HijosOtro == 0) |
      (Hijos == 3 & HijosAutor == 2 & HijosOtro == 1) |
      (Hijos == 3 & HijosAutor == 1 & HijosOtro == 2) |
      (Hijos == 3 & HijosAutor == 0 & HijosOtro == 3) |
      (Hijos == 4 & HijosAutor == 4 & HijosOtro == 0) |
      (Hijos == 4 & HijosAutor == 2 & HijosOtro == 2) |
      (Hijos == 4 & HijosAutor == 1 & HijosOtro == 3) |
      (Hijos == 0 & HijosAutor == 0 & HijosOtro == 0) |
      (Hijos== 'NULO' & HijosAutor == 'NULO' & HijosOtro == 'NULO')| 
      (Hijos== 'NULO' & HijosAutor == 0 & HijosOtro == 'NULO')
  ))



#35. Discapacidad:  108 nulos
sum(is.na(ciber_por_victima$Discapacidad))
ciber_por_victima %>% group_by(Discapacidad) %>% summarise( n=n())

#35.1. Tipo de discapacidad: Tipo de discapacidad hay 258 nulos,
ciber_por_victima %>% group_by(TipoDiscapacidad) %>% summarise( n=n())

#transformamos los de la categria 4 (ns sabe) en nulos
ciber_por_victima$TipoDiscapacidad[(ciber_por_victima$TipoDiscapacidad)== 4] <- NA

ciber_por_victima$TipoDiscapacidad <- factor(
  ciber_por_victima$TipoDiscapacidad,
  levels = c(0,1,2,3,5), 
  labels = c(
    "Física",
    "Mental",
    "Sensorial",
    "Varios Tipos",
    "No tiene discapacidad"
  )
)


#35.2 Gado discapacidad: 314 nulos

sum(is.na(ciber_por_victima$GradoDiscapacidad))
ciber_por_victima %>% group_by(GradoDiscapacidad) %>% summarise( n=n())

#36. Consumo víctima: 
sum(is.na(ciber_por_victima$ConsumoVictima))
ciber_por_victima %>% group_by(ConsumoVictima) %>% summarise( n=n())

#36.1. Tipo consumo: 406 nulos
ciber_por_victima$TipoConsumo 
ciber_por_victima %>% group_by(TipoConsumo) %>% summarise( n=n())

#Transformar el No se sabe
ciber_por_victima$TipoConsumo[(ciber_por_victima$TipoConsumo)== 4] <- NA


ciber_por_victima$TipoConsumo <- factor(
  ciber_por_victima$TipoConsumo,
  levels = c(0,1,2,3),
  labels = c(
    "Alcohol",
    "Drogas",
    "Ambos",
    "No consume"
  )
)
ciber_por_victima %>% group_by(TipoConsumo) %>% summarise( n=n())




# 1.3. VARIABLES DÍNAMICAS RELACIONAL --------------

# 37. Tipo de relación con el agresor. 8 NULOS
ciber_por_victima %>% 
  group_by(TipoRelacionAgresor) %>% 
  summarise(n = n())

#transformar los no se sabe 7 en nulos

#categorizar
ciber_por_victima$TipoRelacionAgresor <- factor(
  ciber_por_victima$TipoRelacionAgresor, 
  levels = c(0,1,2,3,4,5,6,7,8,9),
  labels = c("Novio", 
             "Exnovio", 
             "Pareja", 
             "Expareja", 
             "Cónyuge/pareja de hecho", 
             "Separado/Divorciado",
             "Relación abierta",
             "Otra",
             NA,
             "Relación sentimental Intermitente"
  )
  
)

ciber_por_victima %>% group_by(TipoRelacionAgresor) %>% summarise( n=n())



#38. TipoRelacionR: 9 NULOS
sum(is.na(ciber_por_victima$TipoRelacion_R))
ciber_por_victima %>% group_by(TipoRelacion_R) %>% summarise( n=n())

#39. RelacionIntermitente: 296 nulos
sum(is.na(ciber_por_victima$RelacionIntermitente))
ciber_por_victima %>% 
  group_by(RelacionIntermitente) %>% 
  summarise(n = n())

#40. Tiempo de la relacion 661 nulos
sum(is.na(ciber_por_victima$TiempoRelacionMeses))
hist(ciber_por_victima$TiempoRelacionMeses)
hist(ciber_por_victima$TiempoRelacionMeses/12)
summary(ciber_por_victima$TiempoRelacionMeses)

#41. Modelidad de la relación: 135 nulos

sum(is.na(ciber_por_victima$ModalidadRelacion))
ciber_por_victima %>% group_by(ModalidadRelacion) %>% summarise( n=n())
ciber_por_victima$ModalidadRelacion[(ciber_por_victima$ModalidadRelacion)== 2] <- NA

#Caracteristicas de la dinamica violenta

#42. Vicrtimizaciones previas: 14 nulos
sum(is.na(ciber_por_victima$VictimizacionesPrevias))
ciber_por_victima %>% group_by(VictimizacionesPrevias) %>% summarise( n=n())

# En la victima   244 y 258 son nulos cuando deberia de ser 1 por violencia cibernetica, 
# quedan 7 nulos
ciber_por_victima$VictimizacionesPrevias[(ciber_por_victima$IDCaso)== 244] <- 1
ciber_por_victima$VictimizacionesPrevias[(ciber_por_victima$IDCaso)== 258] <- 1

#42.1 Fisicas: 71 nulos
sum(is.na(ciber_por_victima$ViolenciaFisica))
ciber_por_victima %>% 
  group_by(ViolenciaFisica) %>% 
  summarise(n = n())
#42.2. Psicologica: 80 nulos
sum(is.na(ciber_por_victima$ViolenciaPsicologica))
ciber_por_victima %>% 
  group_by(ViolenciaPsicologica) %>% 
  summarise(n = n())
#42.3. Sexual: 96 nulos 
sum(is.na(ciber_por_victima$ViolenciaSexual))
ciber_por_victima %>% 
  group_by(ViolenciaSexual) %>% 
  summarise(n = n())
#42.4: Emocional: 69 nulos
sum(is.na(ciber_por_victima$ViolenciaEmocional))
ciber_por_victima %>% 
  group_by(ViolenciaEmocional) %>% 
  summarise(n = n())

#42.5: Social:121 
sum(is.na(ciber_por_victima$ViolenciaSocial))
ciber_por_victima %>% 
  group_by(ViolenciaSocial) %>% 
  summarise(n = n())

#42.6: Economica: 106
sum(is.na(ciber_por_victima$ViolenciaEconomica))
hist(ciber_por_victima$ViolenciaEconomica)
ciber_por_victima %>% 
  group_by(ViolenciaEconomica) %>% 
  summarise(n = n())

# 42.7. Violencia Vicaria
ciber_por_victima %>% 
  group_by(ViolenciaVicaria) %>% 
  summarise(n = n())

ciber_por_victima$ViolenciaVicaria[(ciber_por_victima$ViolenciaVicaria)== 9] <- 0

# 42.8. Violencia Cibernética
ciber_por_victima %>% 
  group_by(ViolenciaCibernetica) %>% 
  summarise(n = n())



#43. Violencia estando la victima embarazada
ciber_por_victima$ViolenciaEmbarazo[(ciber_por_victima$ViolenciaEmbarazo)== 2] <- NA

ciber_por_victima %>% group_by(ViolenciaEmbarazo) %>% summarise( n=n())

#2 que son dos? Victima 170

# 44. Violencia defensiva de la víctima
ciber_por_victima$ViolenciaContraTerceros[(ciber_por_victima$ViolenciaContraTerceros)== 2] <- NA

ciber_por_victima %>% 
  group_by(ViolenciaContraTerceros) %>% 
  summarise(n = n())

# 45. Violencia contra terceros
ciber_por_victima %>% 
  group_by(ViolenciaContraTerceros) %>% 
  summarise(n = n())

# 46. Violencia contra hijos de la víctima
ciber_por_victima$ViolenciaContraHijosVictima[(ciber_por_victima$ViolenciaContraHijosVictima)== 2] <- NA

ciber_por_victima %>% 
  group_by(ViolenciaContraHijosVictima) %>% 
  summarise(n = n())

# 47. Violencia contra familiares
ciber_por_victima$ViolenciaContraFamiliares[(ciber_por_victima$ViolenciaContraFamiliares)== 2] <- NA

ciber_por_victima %>% 
  group_by(ViolenciaContraFamiliares) %>% 
  summarise(n = n())

# 48. Violencia contra amigos/as
ciber_por_victima$ViolenciaContraAmigos[(ciber_por_victima$ViolenciaContraAmigos)== 2] <- NA

ciber_por_victima %>% 
  group_by(ViolenciaContraAmigos) %>% 
  summarise(n = n())

# 49. Daños a objetos
ciber_por_victima$DañosObjetos[(ciber_por_victima$DañosObjetos)== 2] <- NA

ciber_por_victima %>% 
  group_by(DañosObjetos) %>% 
  summarise(n = n())

# 50. InfoViolencia (cualitativa)

ciber_por_victima %>% 
  group_by(InfoViolencia) %>% 
  summarise(n = n())

# 51. Deseo de dejar la relación. Dicotómica: si (1) / no (0)

ciber_por_victima$DeseoDejarRelacion[(ciber_por_victima$DeseoDejarRelacion)== 2] <- NA

ciber_por_victima %>% 
  group_by(DeseoDejarRelacion) %>% 
  summarise(n = n())


# 51.1 Especificar quién desea dejar la relación

ciber_por_victima %>% 
  group_by(EspecificarDeseoDejarRelacion) %>% 
  summarise(n = n())

# Modificar la variable EspecificarDeseoDejarRelacion

ciber_por_victima <- ciber_por_victima %>%
  mutate(EspecificarDeseoDejarRelacion = case_when(
    EspecificarDeseoDejarRelacion %in% c("Ambos", "mutuo") ~ "Ambos",
    EspecificarDeseoDejarRelacion %in% c("Mujer", "Victima", "Víctima", "victima", 
                                         "mujer", "la denunciante sufrió agresiones durante el matrimonio que mantuvo con el autor") ~ "Víctima",
    EspecificarDeseoDejarRelacion %in% c("Victimario", "hombre") ~ "Agresor",
    is.na(EspecificarDeseoDejarRelacion) | EspecificarDeseoDejarRelacion == "" ~ "NA",
    TRUE ~ "NA" # Para cualquier otro valor no contemplado
  ))


# 52. Tiempo de agresión después de la ruptura en meses (numérica)
summary(ciber_por_victima$TiempoAgresionDespuesRupturaMeses)

# 53. Cese de la relación. Dicotómica: si (1) / no (0)
ciber_por_victima %>% 
  group_by(CeseRelacion) %>% 
  summarise(n = n())

# 53.1 Especificar por parte de quién cesó la relación
ciber_por_victima %>% 
  group_by(EspecificarCeseRelacion) %>% 
  summarise(n = n())

# 54. Tiempo del cese de la relación (numérica)
summary(ciber_por_victima$TiempoCeseRelacion)

# 55. Separación legal o divorcio. Dicotómica: si (1) / no (0)
ciber_por_victima %>% 
  group_by(Divorcio) %>% 
  summarise(n = n())

# 56. Acoso y acecho tras la ruptura. Dicotómica: si (1) / no (0)
ciber_por_victima %>% 
  group_by(AcosoyAcecho) %>% 
  summarise(n = n())

# 56.1 Especificar por parte de quién hubo acoso
ciber_por_victima %>% 
  group_by(EspecificarAcosoyAcechoTrasRuptura) %>% 
  summarise(n = n())

# 57. Celos. Dicotómica: si (1) / no (0)
ciber_por_victima %>% 
  group_by(Celos) %>% 
  summarise(n = n())

# 58. Motivos de conflicto en la relación (cualitativa)
ciber_por_victima %>% 
  group_by(MotivosConflictoRelacion) %>% 
  summarise(n = n())

# 58.1 Motivos de conflicto en la relación agrupados (cualitativa)
ciber_por_victima %>% 
  group_by(MotivosConflictoRelacion_R) %>% 
  summarise(n = n())

# 1.4. VARIABLES AUTOR ---------------------------------------------------------

#Edad
#59. Edad Rango
# Transformar la variable EdadRango en categórica con los rangos especificados basándose en Edad
ciber_por_victima <- ciber_por_victima %>%
  mutate(
    AutorEdadRango = case_when(
      AutorEdad < 18 ~ "< 18",
      AutorEdad >= 18 & AutorEdad <= 30 ~ "18-30",
      AutorEdad >= 31 & AutorEdad <= 45 ~ "31-45",
      AutorEdad >= 46 & AutorEdad <= 60 ~ "46-60",
      AutorEdad >= 61 & AutorEdad <= 75 ~ "61-75",
      AutorEdad > 75 ~ "> 75",
      TRUE ~ "Sin clasificación" # Por si hay valores fuera de estos rangos
    )
  )

ciber_por_victima <- ciber_por_victima %>%
  mutate(AutorEdadRango = factor(AutorEdadRango, 
                                 levels = c("< 18", "18-30", "31-45", 
                                            "46-60", "61-75", "> 75")))
ciber_por_victima %>% 
  group_by(AutorEdadRango) %>% 
  summarise(n = n())

# 60. Nacionalidad autor
ciber_por_victima <- ciber_por_victima %>%
  mutate(
    AutorNacionalidad = case_when(
      AutorNacionalidad == 0 ~ "Nacional",
      AutorNacionalidad == 1 ~ "Extranjero",
      AutorNacionalidad == 2 ~ "Doble nacionalidad"
    ),
    AutorNacionalidad = factor(AutorNacionalidad, levels = c("Nacional", "Extranjero", "Doble nacionalidad"))
  )

ciber_por_victima %>% 
  group_by(AutorNacionalidad) %>% 
  summarise(n = n())

# 61. País de nacimiento del autor
ciber_por_victima <- ciber_por_victima %>%
  mutate(
    AutorPaisNacimiento = case_when(
      AutorPaisNacimiento == 1 ~ "Afganistán",
      AutorPaisNacimiento == 2 ~ "Alemania",
      AutorPaisNacimiento == 3 ~ "Argelia",
      AutorPaisNacimiento == 4 ~ "Argentina",
      AutorPaisNacimiento == 5 ~ "Bélgica",
      AutorPaisNacimiento == 6 ~ "Bolivia",
      AutorPaisNacimiento == 7 ~ "Brasil",
      AutorPaisNacimiento == 8 ~ "Bulgaria",
      AutorPaisNacimiento == 9 ~ "Chile",
      AutorPaisNacimiento == 10 ~ "Colombia",
      AutorPaisNacimiento == 11 ~ "Cuba",
      AutorPaisNacimiento == 12 ~ "Ecuador",
      AutorPaisNacimiento == 13 ~ "España",
      AutorPaisNacimiento == 14 ~ "Filipinas",
      AutorPaisNacimiento == 15 ~ "Francia",
      AutorPaisNacimiento == 16 ~ "Georgia",
      AutorPaisNacimiento == 17 ~ "Ghana",
      AutorPaisNacimiento == 18 ~ "Honduras",
      AutorPaisNacimiento == 19 ~ "Italia",
      AutorPaisNacimiento == 20 ~ "Jordania",
      AutorPaisNacimiento == 21 ~ "Lituania",
      AutorPaisNacimiento == 22 ~ "Marruecos",
      AutorPaisNacimiento == 23 ~ "Nicaragua",
      AutorPaisNacimiento == 24 ~ "Nueva Zelanda",
      AutorPaisNacimiento == 25 ~ "Pakistán",
      AutorPaisNacimiento == 26 ~ "Perú",
      AutorPaisNacimiento == 27 ~ "Portugal",
      AutorPaisNacimiento == 28 ~ "Reino Unido",
      AutorPaisNacimiento == 29 ~ "República Dominicana",
      AutorPaisNacimiento == 30 ~ "Rumanía",
      AutorPaisNacimiento == 31 ~ "Rusia",
      AutorPaisNacimiento == 32 ~ "Senegal",
      AutorPaisNacimiento == 33 ~ "Suiza",
      AutorPaisNacimiento == 34 ~ "Ucrania",
      AutorPaisNacimiento == 35 ~ "Venezuela"
    ),
    AutorPaisNacimiento = factor(AutorPaisNacimiento, levels = c("Afganistán", "Alemania", "Argelia", "Argentina", "Bélgica", 
                                                                 "Bolivia", "Brasil", "Bulgaria", "Chile", "Colombia", "Cuba", 
                                                                 "Ecuador", "España", "Filipinas", "Francia", "Georgia", 
                                                                 "Ghana", "Honduras", "Italia", "Jordania", "Lituania", 
                                                                 "Marruecos", "Nicaragua", "Nueva Zelanda", "Pakistán", "Perú", 
                                                                 "Portugal", "Reino Unido", "República Dominicana", "Rumanía", 
                                                                 "Rusia", "Senegal", "Suiza", "Ucrania", "Venezuela"))
  )

ciber_por_victima %>% 
  group_by(AutorPaisNacimiento) %>% 
  summarise(n = n())

#61.1 Continete Naciemiento autor
# Crear la variable ContinenteAutorNacimiento en función del país de nacimiento
ciber_por_victima <- ciber_por_victima %>%
  mutate(ContinenteNacimientoAutor = case_when(
    AutorPaisNacimiento %in% c("España", "Francia", "Italia", "Alemania", "Bélgica", "Portugal", 
                               "Reino Unido", "Rumanía", "Bulgaria", "Lituania", "Suiza") ~ "Europa",
    
    AutorPaisNacimiento %in% c("Argentina", "Bolivia", "Brasil", "Chile", "Colombia", "Cuba", 
                               "Ecuador", "Honduras", "Nicaragua", "Perú", "Venezuela", 
                               "República Dominicana") ~ "América",
    
    AutorPaisNacimiento %in% c("Argelia", "Ghana", "Marruecos", "Senegal") ~ "África",
    
    AutorPaisNacimiento %in% c("Afganistán", "Pakistán", "Jordania", "Georgia", "Rusia", 
                               "Ucrania", "Filipinas") ~ "Asia",
    
    AutorPaisNacimiento %in% c("Nueva Zelanda") ~ "Oceanía",
    
    TRUE ~ NA  # Para casos no especificados o NA
  ))

ciber_por_victima %>% 
  group_by(ContinenteNacimientoAutor) %>% 
  summarise(n = n())

# 62. Situación legal
ciber_por_victima <- ciber_por_victima %>%
  mutate(
    AutorSituacionLegal = case_when(
      AutorSituacionLegal == 0 ~ "Regular",
      AutorSituacionLegal == 1 ~ "Irregular",
      AutorSituacionLegal == 2 ~ "Nacional",
      AutorSituacionLegal == 3 ~ NA,
      AutorSituacionLegal == 4 ~ "No vive en España"
    ),
    AutorSituacionLegal = factor(AutorSituacionLegal, levels = c("Regular", "Irregular", "Nacional", NA, "No vive en España"))
  )


ciber_por_victima %>% 
  group_by(AutorSituacionLegal) %>% 
  summarise(n = n())

# 63. Situación laboral
ciber_por_victima <- ciber_por_victima %>%
  mutate(
    AutorSituacionLaboral = case_when(
      AutorSituacionLaboral == 0 ~ "Ocupado",
      AutorSituacionLaboral == 1 ~ "Parado",
      AutorSituacionLaboral == 2 ~ "Estudiante",
      AutorSituacionLaboral == 3 ~ "Rentista",
      AutorSituacionLaboral == 4 ~ "Pensionista",
      AutorSituacionLaboral == 5 ~ "Otra situación laboral",
      AutorSituacionLaboral == 6 ~ "Variaciones de la situación laboral",
      AutorSituacionLaboral == 7 ~ NA
    ),
    AutorSituacionLaboral = factor(AutorSituacionLaboral, levels = c("Ocupado", "Parado", "Estudiante", "Rentista", 
                                                                     "Pensionista", "Otra situación laboral", 
                                                                     "Variaciones de la situación laboral"))
  )
ciber_por_victima %>% 
  group_by(AutorSituacionLaboral) %>% 
  summarise(n = n())

# 63.1 Empleo y Empleo_Categorías
ciber_por_victima <- ciber_por_victima %>%
  mutate(
    AutorEmpleo_Categorías = case_when(
      AutorEmpleo_Categorías == 0 ~ "Baja",
      AutorEmpleo_Categorías == 1 ~ "Ayuda",
      AutorEmpleo_Categorías == 2 ~ "Autónomo",
      AutorEmpleo_Categorías == 3 ~ "Banca",
      AutorEmpleo_Categorías == 4 ~ "Cazador",
      AutorEmpleo_Categorías == 5 ~ "Comercio",
      AutorEmpleo_Categorías == 6 ~ "Construcción",
      AutorEmpleo_Categorías == 7 ~ "Dependiente",
      AutorEmpleo_Categorías == 8 ~ "En una empresa",
      AutorEmpleo_Categorías == 9 ~ "Fontanería",
      AutorEmpleo_Categorías == 10 ~ "Hostelería",
      AutorEmpleo_Categorías == 11 ~ "Industria",
      AutorEmpleo_Categorías == 12 ~ "Limpieza",
      AutorEmpleo_Categorías == 13 ~ "Músico",
      AutorEmpleo_Categorías == 14 ~ "Operario",
      AutorEmpleo_Categorías == 15 ~ "Primer sector",
      AutorEmpleo_Categorías == 16 ~ "Seguridad",
      AutorEmpleo_Categorías == 17 ~ "Técnico de mantenimiento",
      AutorEmpleo_Categorías == 18 ~ "Traficante",
      AutorEmpleo_Categorías == 19 ~ "Transporte"
    ),
    AutorEmpleo_Categorías = factor(AutorEmpleo_Categorías, levels = c("Baja", "Ayuda", "Autónomo", "Banca", "Cazador", 
                                                                       "Comercio", "Construcción", "Dependiente", 
                                                                       "En una empresa", "Fontanería", "Hostelería", 
                                                                       "Industria", "Limpieza", "Músico", "Operario", 
                                                                       "Primer sector", "Seguridad", "Técnico de mantenimiento", 
                                                                       "Traficante", "Transporte"))
  )

# 64. Vive con víctima
ciber_por_victima <- ciber_por_victima %>%
  mutate(
    AutorViveVictima = factor(AutorViveVictima, levels = c(0, 1), labels = c("No", "Sí"))
  )

ciber_por_victima %>% 
  group_by(AutorViveVictima) %>% summarise(n = n())


# 65. Hijos y sus variables relacionadas



#65.1. Nº total de hijos numerica
ciber_por_victima %>% 
  group_by(AutorNHijosVictima) %>% summarise(n = n())

#65.2. Nº de hijos con la victima 
ciber_por_victima %>% 
  group_by(AutorNHijos) %>% summarise(n = n())



# 66. Discapacidad reconocida
    
ciber_por_victima %>% 
  group_by(AutorDiscapacidad) %>% 
  summarise(n = n())

# 66.2 Grado de discapacidad 
ciber_por_victima %>% 
  group_by(AutorGradodiscapacidad) %>% 
  summarise(n = n())

# 66.2.1 Especificación discapacidad
ciber_por_victima %>% 
  group_by(AutorEspecificacionDiscapacidad) %>% 
  summarise(n = n())

# 67. Antecedentes

ciber_por_victima$AutorAntecedentes[ciber_por_victima$AutorAntecedentes == 4] <- NA

ciber_por_victima %>% 
  group_by(AutorAntecedentes) %>% 
  summarise(n = n())

# 67.1 Antecedentes_R (si/no)
ciber_por_victima %>% 
  group_by(AutorAntecedentes_R) %>% 
  summarise(n = n())

#67.1.1: Atecendentes_policiales


ciber_por_victima <- ciber_por_victima %>%
  mutate(
    Antecedentes_policiales = case_when(
      AutorAntecedentes %in% c(2, 3) ~ 1,  # Si tiene antecedentes policiales
      AutorAntecedentes %in% c(0, 1, 4) ~ 0,  # Si no tiene antecedentes policiales
      TRUE ~ as.numeric(NA)  # Mantiene los valores nulos
    ),
    Antecedentes_judiciales = case_when(
      AutorAntecedentes %in% c(1, 3) ~ 1,  # Si tiene antecedentes judiciales
      AutorAntecedentes %in% c(0, 2, 4) ~ 0,  # Si no tiene antecedentes judiciales
      TRUE ~ as.numeric(NA)  # Mantiene los valores nulos
    )
  )


# 67.2 Categoría delictiva
ciber_por_victima %>% 
  group_by(AutorCategoriaDelictiva) %>% 
  summarise(n = n())

# 67.2.1 Especificar delitos por categoría
ciber_por_victima %>% 
  group_by(AutorDelitoPersonas) %>% summarise(n = n())

ciber_por_victima %>% 
  group_by(AutorDelitoLibertadSexual) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(AutorDelitoOrdenPublico) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(AutorDelitoSeguridadVial) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(AutorDelitoSaludPublica) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(AutorDelitoLibertad) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(AutorDelitoDeberesFamiliares) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(AutorDelitoPatrimonio) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(AutorDelitoAdministracionJusticia) %>% summarise(n = n())

# 67.3 Antecedentes Viogen (si/no)
ciber_por_victima %>% 
  group_by(AntecedentesVioGen) %>% summarise(n = n())

# 67.4 Delitos contra la víctima
ciber_por_victima %>% 
  group_by(AutorDelitosContraVictima) %>% summarise(n = n())

ciber_por_victima$AutorDelitosContraVictima[ciber_por_victima$AutorDelitosContraVictima == 2] <- NA


# 67.4.1 Especificar delitos contra la víctima
ciber_por_victima %>% 
  group_by(DelMalosTratos) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(DelAmenazas) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(DelQuebrantamiento) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(DelCoacciones) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(DelDaños) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(DelAcoso) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(DelDesYRevSecretos) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(DelLesiones) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(DelImpagoPension) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(DelVejaciones) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(DelAbusoSexual) %>% summarise(n = n())

# 67.5 Delitos contra parejas anteriores
ciber_por_victima %>% 
  group_by(AutorDelitosContraParejasAnteriores) %>% summarise(n = n())

ciber_por_victima$AutorDelitosContraParejasAnteriores[(ciber_por_victima$AutorDelitosContraParejasAnteriores)== 2] <- NA

# 67.5.1 Categoría delictiva contra parejas anteriores
ciber_por_victima %>% 
  group_by(AutorCategoriaDelictivaContraParejasAnteriores) %>% summarise(n = n())

# 68. Estancia en prisión
ciber_por_victima %>% 
  group_by(AutorEstanciaPrision) %>% summarise(n = n())

ciber_por_victima$AutorEstanciaPrision[(ciber_por_victima$AutorEstanciaPrision)== 2] <- NA


# 68.1 Estancia en prisión por delitos de VG
ciber_por_victima %>% 
  group_by(AutorEstanciaPrisionPorDelitosVG) %>% summarise(n = n())

ciber_por_victima$AutorEstanciaPrisionPorDelitosVG[(ciber_por_victima$AutorEstanciaPrisionPorDelitosVG)== 2] <- NA

# 68.2 Estancia en prisión por otros delitos
ciber_por_victima %>% 
  group_by(AutorEstanciaPrisionPorOtros) %>% summarise(n = n())

ciber_por_victima$AutorEstanciaPrisionPorOtros[(ciber_por_victima$AutorEstanciaPrisionPorOtros)== 2] <- NA

# 68.3 Número de veces en prisión (numérica)
summary(ciber_por_victima$AutorNumEstanciaPrision)

# 68.4 Tiempo total en prisión (numérica)
summary(ciber_por_victima$AutorTiempoTotalEstanciaPrisionMeses)

# 69. Edad de inicio de la carrera delictiva
ciber_por_victima %>% 
  group_by(AutorEdadInicioCarreraDelictiva) %>% summarise(n = n())

# 70. Consumo de sustancias
ciber_por_victima %>% 
  group_by(AutorConsumo) %>% summarise(n = n())

# 70.1 Tipo de consumo

ciber_por_victima %>% 
  group_by(AutorTipoConsumo) %>% summarise(n = n())
ciber_por_victima$AutorTipoConsumo[(ciber_por_victima$AutorTipoConsumo)== 4] <- NA

# 70.2 Tipo de consumo escrito (cualitativo)
ciber_por_victima %>% 
  group_by(AutorTipoConsumoEscrito) %>% summarise(n = n())

# 70.3 Frecuencia de consumo
ciber_por_victima %>% 
  group_by(AutorFrecuenciaConsumo) %>% summarise(n = n())

# 70.4 Especificar tipo de consumo
ciber_por_victima %>% 
  group_by(Alcohol_Consumo) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(Cannabis_Consumo) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(Anfetamina_Consumo) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(Cocaína_Consumo) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(Crack_Consumo) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(Speed_Consumo) %>% summarise(n = n())
ciber_por_victima %>% 
  group_by(Heroína_Consumo) %>% summarise(n = n())

# Creación de varibale Consumo Drogas y alcohol 
ciber_por_victima <- ciber_por_victima %>%
  mutate(
    Autor_ConsumoDrogas = if_else(
      Cannabis_Consumo == 1 | Anfetamina_Consumo == 1 | Cocaína_Consumo == 1 | 
        Crack_Consumo == 1 | Speed_Consumo == 1 | Heroína_Consumo == 1, 1, 0, missing = NA
    ),
    
    Autor_ConsumoAlcohol = if_else(
      Alcohol_Consumo == 1, 1, 0, missing = NA
    )
  )

ciber_por_victima %>% 
  group_by(Autor_ConsumoAlcohol) %>% summarise(n = n())

ciber_por_victima %>% 
  group_by(Autor_ConsumoDrogas) %>% summarise(n = n())


# Cargar paquete necesario
library(dplyr)

# Asegurarnos de que el dataframe se llama correctamente
ciber_por_victima <- ciber_por_victima %>%
  mutate(NumeroDeVictimizaciones = rowSums(select(., Stalking, Sextorsion, Fraping, 
                                                  Denigration, Revenge_Porn, Flaming, 
                                                  Impersonation, Sexting, Doxing), 
                                           na.rm = TRUE))

ciber_por_victima %>% 
  group_by(NumeroDeVictimizaciones) %>% summarise(n = n())



#ELIMINAR VARIABLES


ciber_por_victima <- ciber_por_victima %>%
  select(-Dia, -Mes, -Año,- NA.x, -NA.y, - "NA" )


#install.packages("openxlsx")
library(openxlsx)

# Exportar usando openxlsx

write.xlsx(ciber_por_victima, "D:/BASES/Proyecto/R/A. Victimas/A.1.Tabla_Ciber_Victima_RECUENTO.xlsx")





