# Cargar librerías necesarias
library(readxl)
library(ggplot2)
library(dplyr)

# Cargar datos desde el archivo Excel
Tabla_ciber_casos <- read_excel("R/A. Victimas/A.1.Tabla_Ciber_Victima_RECUENTO.xlsx")

# Creación de variable demográfica de la víctima
Tabla_ciber_casos <- Tabla_ciber_casos %>%
  mutate(
    VictimaNacidaEspaña = ifelse(PaisNacimiento == "España", 1, 0),
    AutorNacidoEspaña = ifelse(AutorPaisNacimiento == "España", 1, 0)
  )
  
# Definir las variables a seleccionar
variables_seleccionadas <- c(
  "EdadRango", "Nacionalidad", "SituacionLegal", "ViveAutor",
  "TipoRelacion_R", "HijosConAutor", "Hijos_R", "VictimaNacidaEspaña",
  "AutorEdadRango", "AutorNacionalidad", "AutorSituacionLegal", 
  "Autor_ConsumoAlcohol", "Autor_ConsumoDrogas", "AutorNacidoEspaña",
  "DelMalosTratos", "DelAmenazas", "DelQuebrantamiento", 
  "DelCoacciones", "DelDaños", "DelAcoso", "DelDesYRevSecretos",
  "DelLesiones", "DelImpagoPension", "DelVejaciones", 
  "DelAbusoSexual", "AutorDelitosContraParejasAnteriores",
  "AutorDelitoPersonas", "AutorDelitoLibertadSexual", 
  "AutorDelitoOrdenPublico", "AutorDelitoSeguridadVial", 
  "AutorDelitoSaludPublica", "AutorDelitoLibertad", 
  "AutorDelitoDeberesFamiliares", "AutorDelitoPatrimonio", 
  "AutorDelitoAdministracionJusticia",
  "Info_Hecho_Ciberacoso", "Info_Hecho_Ciberamenaza", 
  "Info_Hecho_Ciberquebrantamiento_de_condena", 
  "Info_Hecho_Descubrimiento_y_revelacion_de_secretos", 
  "Info_Hecho_Coacciones", "Info_Hecho_Ciberofensas", 
  "Info_Hecho_Contacto_no_deseado", "Info_Hecho_Suplantacion_de_identidad",
    "VulneracionOrdenProteccion", "VictimizacionesPrevias", "DenunciasPreviasContraAutor"
)


# Seleccionar variables relevantes
Tabla_ciber_casos <- Tabla_ciber_casos %>%
  select(all_of(variables_seleccionadas))

# Renombrar columnas eliminando el prefijo "Info_Hecho_" si lo tienen
names(Tabla_ciber_casos) <- gsub("^Info_Hecho_", "", names(Tabla_ciber_casos))

# Verificar la estructura de la tabla resultante
str(Tabla_ciber_casos)

# ===============================================
# Exploración de nulos
# ===============================================
# Convert all variables to factors
Tabla_ciber_casos <- Tabla_ciber_casos %>%
  mutate(across(everything(), as.factor))

# Analyze missing values
# Count missing values per row
nulos_por_fila <- rowSums(is.na(Tabla_ciber_casos))
sum(nulos_por_fila) # Total missing values

# Create dataframe for visualization
df_nulos <- data.frame(Fila = 1:length(nulos_por_fila), Nulos = nulos_por_fila)

# Plot histogram of missing values per row
ggplot(df_nulos, aes(x = Nulos)) +
  geom_histogram(binwidth = 1, fill = "#69b3a2", color = "black", alpha = 0.7) +
  labs(
    title = "Distribución de los valores nulos en el conjunto de datos",
    x = "Número de valores nulo por observación",
    y = "Frequencia de observaciones"
  ) +
  
  scale_x_continuous(breaks = seq(min(df_nulos$Nulos), max(df_nulos$Nulos), by = 1)) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 10)) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    axis.title = element_text(face = "bold")
  )

# Count missing values per column
nulos_por_columna <- colSums(is.na(Tabla_ciber_casos))
total_filas <- nrow(Tabla_ciber_casos)


# Create dataframe for visualization
df_nulos_columna <- data.frame(
  Columna = names(nulos_por_columna),
  Nulos = nulos_por_columna,
  Porcentaje = (nulos_por_columna / total_filas) * 100
)

# Sort by number of missing values
df_nulos_columna <- df_nulos_columna[order(df_nulos_columna$Nulos, decreasing = TRUE), ]

# Plot bar chart of missing values per column
ggplot(df_nulos_columna, aes(x = reorder(Columna, -Nulos), y = Nulos)) +
  geom_bar(stat = "identity", fill = "#FF9999", color = "black", alpha = 0.8) +
  geom_text(aes(label = paste0(round(Porcentaje, 1), "%")), 
            hjust = -0.2, size = 4, color = "black") +
  labs(
    title = "Valores Faltantes por Variable",
    x = "Variables",
    y = "Número de Valores Faltantes"
  ) +
  coord_flip() +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    axis.title = element_text(face = "bold")
  )

#DenunciasPreviasContraAutor

Tabla_ciber_casos$DenunciasPreviasContraAutor<- factor(
  Tabla_ciber_casos$DenunciasPreviasContraAutor,
  levels = c(0,1),  # Valores originales
  labels = c(
    "No",
    "Sí"
  )
)

Tabla_ciber_casos %>% group_by(DenunciasPreviasContraAutor) %>% summarise( n=n())



#Vulneracion de la orden

Tabla_ciber_casos$VulneracionOrdenProteccion  <- factor(
  Tabla_ciber_casos$VulneracionOrdenProteccion ,
  levels = c(0,1,2,3),  # Valores originales
  labels = c(
    "No",
    "Sí",
    "No hubo orden",
    "No hay denucia"
  )
)

Tabla_ciber_casos %>% group_by(VulneracionOrdenProteccion) %>% summarise( n=n())


#Victimizaciones Previas

Tabla_ciber_casos$VictimizacionesPrevias<- factor(
  Tabla_ciber_casos$VictimizacionesPrevias,
  levels = c(0,1),  # Valores originales
  labels = c(
    "No",
    "Sí"
  )
)



view(Tabla_ciber_casos)

write.xlsx(Tabla_ciber_casos, "Tabla_Ciber_caso_nueva.xlsx")

library(readxl)